import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)

    def result = """
{
  "City" : "${json.name}",
  "Temperature" : "${json.main.temp} °C",
  "Weather" : "${json.weather[0].main}",
  "Humidity" : "${json.main.humidity}%"
}
"""

    message.setBody(result)

    return message
}